rm common trials convert.py remove_clip_fintune.py train_qat.py train.py -r
cp ../MobileSR/common . -r
cp ../MobileSR/trials . -r
cp ../MobileSR/convert.py . -r
cp ../MobileSR/remove_clip_fintune.py . -r
cp ../MobileSR/train_qat.py . -r
cp ../MobileSR/train.py . -r
