''' convert '''
import pickle
import os
import numpy as np
import tqdm
import tensorflow as tf


def save_gpu_memory():
    ''' save_gpu_memory '''
    tf.config.set_soft_device_placement(True)
    physical_devices = tf.config.list_physical_devices('GPU')
    for physical_device in physical_devices:
        tf.config.experimental.set_memory_growth(physical_device, True)


def representative_dataset_gen():
    ''' representative_dataset_gen '''
    for i in tqdm.tqdm(range(801, 901), desc='rep_dataset'):
        lr_path = f'datasets/DIV2K/DIV2K_valid_LR_bicubic/X3/{i:04d}.pt'
        with open(lr_path, 'rb') as f:
            lr = pickle.load(f)
        lr = lr.astype(np.float32)
        lr = np.expand_dims(lr, 0)
        yield [lr]


# set input tensor to [1, 360, 640, 3] for testing time
def representative_dataset_gen_time():
    ''' representative_dataset_gen_time '''
    lr_path = 'datasets/DIV2K/DIV2K_valid_LR_bicubic/X3/0801.pt'
    with open(lr_path, 'rb') as f:
        lr = pickle.load(f)
    lr = lr.astype(np.float32)
    lr = np.expand_dims(lr, 0)
    yield [lr[:, 0:360, 0:640, :]]


def convert_model(model_path, tflite_path):
    ''' convert_model '''
    model = tf.saved_model.load(model_path)
    concrete_func = model.signatures[tf.saved_model.DEFAULT_SERVING_SIGNATURE_DEF_KEY]
    concrete_func.inputs[0].set_shape([1, None, None, 3])
    converter = tf.lite.TFLiteConverter.from_concrete_functions([concrete_func])
    converter.experimental_new_converter=True
    tflite_model = converter.convert()
    with open(tflite_path, "wb") as f:
        f.write(tflite_model)


def convert_model_quantize(model_path, tflite_path, time=False):
    ''' convert_model_quantize '''
    if time:
        tensor_shape = [1, 360, 640, 3]
        rep = representative_dataset_gen_time
    else:
        tensor_shape = [1, None, None, 3]
        rep = representative_dataset_gen

    model = tf.saved_model.load(model_path)
    concrete_func = model.signatures[tf.saved_model.DEFAULT_SERVING_SIGNATURE_DEF_KEY]
    concrete_func.inputs[0].set_shape(tensor_shape)
    converter = tf.lite.TFLiteConverter.from_concrete_functions([concrete_func])
    converter.experimental_new_converter=True
    converter.experimental_new_quantizer=True
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.representative_dataset = rep
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type = tf.uint8
    converter.inference_output_type = tf.uint8
    quantized_tflite_model = converter.convert()
    with open(tflite_path, 'wb') as f:
        f.write(quantized_tflite_model)


def main():
    ''' main '''
    # save gpu memory
    save_gpu_memory()

    # convert model
    os.makedirs('TFLite/', exist_ok=True)
    ## model.tflite (INT8, 360)
    convert_model_quantize('checkpoint-qat', 'TFLite/model.tflite', time=True)
    ## model_none.tflite (INT8, None)
    convert_model_quantize('checkpoint-qat', 'TFLite/model_none.tflite', time=False)
    ## model_none_float.tflite (float32, None)
    convert_model('checkpoint', 'TFLite/model_none_float.tflite')


if __name__ == '__main__':
    main()
