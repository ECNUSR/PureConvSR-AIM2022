# data preparation

Div2k verification set is required for quantification. Due to the limitation of submission space, no dataset is provided in this directory, so you need to download it yourself. The folder structure is as follows:

```bash
Model/
├── datasets
    ├── DIV2K
        ├── DIV2K_valid_LR_bicubic
            ├── X3
                ├── 0801.pt
                ├── 0802.pt
                ├── ...
                ├── 0900.pt
```

# Introduction to folder meaning

`checkpoint`: Model checkpoints(float32).

`checkpoint-qat`: Model checkpoints that need to be quantified(int8).

`main.py`: Program entry.

# How to run
```bash
python main.py
```
